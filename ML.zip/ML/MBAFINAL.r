library(arules)
library(arulesViz)
library(datasets)
data("Groceries")
dataset = Groceries
summary(Groceries)
rules=apriori(data = dataset,parameter = list(supp = 0.01, conf = 0.09, target = "rules"))
summary(rules)
itemFrequencyPlot(Groceries,support=0.10)
itemFrequencyPlot(Groceries,topN=15)
r = sort(rules,decreasing=TRUE,by="confidence")
r             
r[1:8]
inspect(r[1:8])
plot(r[1:10], method="graph", control=list(type="items"),engine = "interactive")


