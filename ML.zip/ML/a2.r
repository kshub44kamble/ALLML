#Include Libraries
#For mse()
library("Metrics")
library("lattice")
#For cv.lm
library("DAAG")

# Loading Dataset

Data <- read.csv("/home/shruti/Documents/BE/ML/Advertising.csv")
Data

# Splitting Dataset into training and testing dataset

Training = Data[1:140,]
Testing = Data[141:200,]

# Formation of model for training dataset.
#lm is used to fit linear models and carry out regression
#lm returns object of class lm

TVm <- lm(Sales~TV,data = Training)
TVm

Radiom <- lm(Sales~Radio,data = Training)
Radiom

Newsm <- lm(Sales~Newspaper,data = Training)
Newsm

# Model Plotting.

plot(Training$Sales~Training$TV,xlab = "TV",ylab = "Sales")
abline(TVm)

plot(Training$Sales~Training$Radio, xlab = "Radio",ylab = "Sales")
abline(Radiom)

plot(Training$Sales~Training$Newspaper,xlab = "Newspaper",ylab = "Sales")
abline(Newsm)

# Prediction for model for training Data

TV1 <- predict(TVm, Training)
Radio1 <- predict(Radiom, Training)
News1 <- predict(Newsm,Training)

# Prediction for model for training Data

TV2<- predict(TVm, Testing)
Radio2 <- predict(Radiom, Testing)
News2 <- predict(Newsm,Testing)

# Calculation of Mean Squared Error For Training Dataset
#mse(Predicted, Actual)

TVTrainMSE <- mse(Training$Sales, TV1)
TVTestMSE

RadioTrainMSE <- mse(Training$Sales, Radio1)
RadioTestMSE

NewsTrainMSE <- mse(Training$Sales, News1)
NewsTrainMSE

# Calculation of Mean Squared Error For Testing Dataset

TVTestMSE <- mse(Testing$Sales, TV2)
TVTestMSE

RadioTestMSE <- mse(Testing$Sales, Radio2)
RadioTestMSE

NewsTestMSE <- mse(Testing$Sales, News2)
NewsTestMSE

# Combining all Mean Squared Errors.

trainMSE <- c(TVTrainMSE, RadioTrainMSE, NewsTrainMSE)
trainMSE

testMSE <- c(TVTestMSE, RadioTestMSE, NewsTestMSE)
testMSE

# Plotting Mean Squared Error for Training and Testing Dataset.

barplot(trainMSE, width = 0.02, xlab = "Data", ylab = "Error", main ="Training Error")
barplot(testMSE, width = 0.02, xlab = "Data", ylab = "Error" ,main = "Testing Error")

# Apply Cross Validation and plot graph for error


Model=cv.lm(Data,(Sales~TV),m=10)

