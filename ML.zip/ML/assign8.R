a=iris
a
View(a)
summary(a)
t=a[1:4]
t

cor(t)
mean(cor(t))
eigen(cor(t))

PCA=princomp(t)
PCA
plot(PCA,type="l")
biplot(PCA) # Combiation of loadigs and scores
screeplot(PCA)  #Variation in pricipal compoents caputers from the data
 
PCA$loadings  
PC=PCA$scores
cor(PC)
eigen(cor(PC))
View(PC)
