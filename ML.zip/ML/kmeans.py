import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs
#Generate isotropic Gaussian blobs for clustering.
data = make_blobs(n_samples=300, n_features=3, centers=4,
                  cluster_std=2.6, random_state=60)

#Creates new figure
fig = plt.figure()
#1*1 grid and 1st subplot
ax = fig.add_subplot(111)

points = data[0]
print("Data points:")
print(points)

#Kmeans clustering with number of clusters and centroids passed as argument
model = KMeans(n_clusters=3)

#Train the model
model.fit(points)

print("Model Cluster Centers:")
print(model.cluster_centers_)

#Compute cluster centers and predict cluster index for each sample.
y_km = model.fit_predict(points)

#Scatter plot
ax.scatter(points[y_km == 0, 0], points[y_km == 0, 1], points[y_km == 0, 2], c='green')
ax.scatter(points[y_km == 2, 0], points[y_km == 2, 1], points[y_km == 2, 2], c='blue')
ax.scatter(points[y_km == 1, 0], points[y_km == 1, 1], points[y_km == 2, 2], c='orange')
plt.show()
