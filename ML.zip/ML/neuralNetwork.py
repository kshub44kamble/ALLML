import numpy as np
import pandas as pd

#Import data using pandas
dataset = pd.read_csv('/home/shubham/Desktop/diabetes.csv')
#Columns in dataset:
#Pregnancies, Glucose, BP, SkinThickness, Insulin, BMI, DiabetesPedireeFunction, Age, Outcome

#Create matrices of features and target variable
#iloc returns a series when one row is selected and a dataframe in case of multiple rows
X = dataset.iloc[:,:8].values
y = dataset.iloc[:,8].values

#Splitting data
from sklearn.model_selection import train_test_split
#train_test_split(*arrays, **options)
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size = 0.2)

from keras.models import Sequential
#For initializing NN
from keras.layers import Dense
#To add hidden layers

classifier = Sequential()

#Input layer and 1st hidden layer
#output_dim = Number of nodes
#init = Initialization of Stochastic Gradient Descent
#relu function used in the hidden layer

classifier.add(Dense(output_dim = 6, init = 'uniform', activation = 'relu', input_dim = 8))

#2nd hidden layer
classifier.add(Dense(output_dim = 6, init = 'uniform', activation = 'relu'))

#Adding the output layer
#sigmoid function used in the output layer
classifier.add(Dense(output_dim = 1, init = 'uniform', activation = 'sigmoid'))

#Optimizer = Algorithm used to set optimal set of weights
#Adam = Type of Stochastic Gradient Descent
#SGD depends on loss
#binary_crossentropy, since output is binary
classifier.compile(optimizer = 'adam', loss = 'binary_crossentropy', metrics = ['accuracy'])

#Fitting
#Batch size = Number of observations
#Epoch = Number of iterations
classifier.fit(X_train, y_train, batch_size = 10, nb_epoch = 60)

#Predicting
y_pred = classifier.predict(X_test)
y_pred = (y_pred > 0.5)

from sklearn.metrics import confusion_matrix
#Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print(cm[0][0]+cm[1][1]/cm.sum())

#Visualization with ANNvisualizer
from ann_visualizer.visualize import ann_viz
ann_viz(classifier,view = True, filename = "network.gv", title = "Neural Network(Diabetes Dataset)")
