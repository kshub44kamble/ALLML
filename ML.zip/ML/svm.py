from sklearn import datasets
from sklearn import svm
import numpy as np
import matplotlib.pyplot as plt

#Import dataset
iris = datasets.load_iris()
#Datasets features are :
#Sepal Length, Sepal Width, Petal Length, Petal Width

#Taking sepal length and sepal width in X and target variable in y
X = iris.data[:,:2]
y = iris.target

#SVM regularization parameter i.e. how much you want to avoid misclassifying a training example
#Larger C, less training errors
C = 1.0

#SVC with linear kernel
#Uses One-vs-one algorithm
svc = svm.SVC(kernel = 'linear', C = C).fit(X, y)
scoreSVC = svc.score(X,y)

#LinearSVC
#Uses One-vs-all algorithm
lin_svc = svm.LinearSVC(C = C).fit(X,y)
scorelin_svc = lin_svc.score(X,y)

#SVC with RBF kernel
#Radial basis function
#Used with non linear data
rbf_svc = svm.SVC(kernel = 'rbf', gamma = 0.7, C = C).fit(X, y)
scorerbf_svc = rbf_svc.score(X,y)

#SVC with polynomial degree 3 kernel
poly_svc = svm.SVC(kernel = 'poly', degree = 3, C = C).fit(X, y)
scorepoly_svc = poly_svc.score(X,y)

#Mean accuracy values
print('***SCORES***')
print('SVC with linear kernel %s' % scoreSVC)
print('Linear SVC %s' % scorelin_svc)
print('SVC with RBF kernel %s' % scorerbf_svc)
print('SVC with polynomial kernel %s' % scorepoly_svc)

h = .02  # step size in the mesh

# create a mesh to plot in
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
	                     np.arange(y_min, y_max, h))
# title for the plots
titles = ['SVC with linear kernel',
	   'LinearSVC (linear kernel)',
	    'SVC with RBF kernel',
	    'SVC with polynomial (degree 3) kernel']


for i, clf in enumerate((svc, lin_svc, rbf_svc, poly_svc)):
	 # Plot the decision boundary. For that, assign a color to each
	 # point in the mesh [x_min, x_max]x[y_min, y_max].

     #Divides the figure into m*n matrix and selects pth axes object for the current plot
	 plt.subplot(2, 2, i + 1)

	 #Amount of height and width between subplots
	 plt.subplots_adjust(wspace=0.4, hspace=0.4)

	 Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])

	 # Put the result into a color plot
	 #Gives a new shape without changing its data
	 Z = Z.reshape(xx.shape)
	 plt.contourf(xx, yy, Z, cmap=plt.cm.coolwarm, alpha=0.8)

	 # Plot also the training points
	 plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.coolwarm)
	 plt.xlabel('Sepal length')
	 plt.ylabel('Sepal width')
	 plt.xlim(xx.min(), xx.max())
	 plt.ylim(yy.min(), yy.max())
	 plt.xticks(())
	 plt.yticks(())
	 plt.title(titles[i])

plt.show()
